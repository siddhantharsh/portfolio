import React from "react"

import SmoothScroll from "./SmoothScroll"

import "./styles.scss"

const App = () => <SmoothScroll />

export default App
